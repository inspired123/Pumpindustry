<?php

namespace cms\news\Models;

use Illuminate\Database\Eloquent\Model;

class LikesModel extends Model
{
    protected $table = 'likes';
}
