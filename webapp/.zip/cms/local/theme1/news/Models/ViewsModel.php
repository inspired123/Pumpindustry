<?php

namespace cms\news\Models;

use Illuminate\Database\Eloquent\Model;

class ViewsModel extends Model
{
    protected $table = 'views';
}
