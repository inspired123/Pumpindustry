<?php

Route::get('/', function () {
    return view('news::site.index');
});
