<?php

namespace cms\sociallinks\Models;

use Illuminate\Database\Eloquent\Model;

class SocialLinksModel extends Model
{
   protected $table = 'social_link';
}
