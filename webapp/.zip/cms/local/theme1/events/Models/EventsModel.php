<?php

namespace cms\events\Models;

use Illuminate\Database\Eloquent\Model;

class EventsModel extends Model
{
    protected $table = "events";
}
