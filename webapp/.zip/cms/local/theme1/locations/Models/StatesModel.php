<?php

namespace cms\locations\Models;

use Illuminate\Database\Eloquent\Model;

class StatesModel extends Model
{
    protected $table = 'states';
}
