<?php

namespace cms\user\Models;

use Illuminate\Database\Eloquent\Model;

class NotificationTokensModel extends Model
{
    protected $table = "notification_tokens";
}
