<?php

namespace cms\user\Models;

use cms\core\user\Models\UserModel as Model;

class UserModel extends Model
{
    public function details() {
    	
    }
}
