<?php

namespace cms\core\configurations\Models;

use Illuminate\Database\Eloquent\Model;

class ConfigurationModel extends Model
{
    protected $table = 'configurations';
}
