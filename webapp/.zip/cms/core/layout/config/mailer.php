<?php
/*
 * mailer lists
 */
return [
    "gmail" => [
        "driver" => "smtp",
        "host" => "smtp.gmail.com",
        "port" => 587,
        "encryption" => "tls",
    ]
];