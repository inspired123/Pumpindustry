@extends('layout::site.master')

@section('sIte_tItle','Home Page')

@section('body')
    <div class="container">
    This is Home page
    </div>
@endsection