<?php
namespace cms\core\layout\Controllers;

/**
* 
*/
class SliderPlugin 
{
	
	function display()
	{
		# code...
	}
}
?>