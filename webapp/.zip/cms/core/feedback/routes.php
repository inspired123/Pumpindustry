<?php
Route::post('dofeedback','FeedBackController@dofeedback')->name('do_feedback');