<?php

namespace cms\core\feedback\Models;

use Illuminate\Database\Eloquent\Model;

class FeedBackModel extends Model
{
    protected $table = 'feedback';
}
