<?php
namespace cms\core\feedback\Controllers;

class FeedbackPlugin
{
    function display()
    {

    }
}