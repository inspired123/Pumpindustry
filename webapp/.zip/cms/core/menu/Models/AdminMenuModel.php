<?php

namespace cms\core\menu\Models;

use Illuminate\Database\Eloquent\Model;

class AdminMenuModel extends Model
{
    protected $table = 'admin_menu';

    public function permissions()
    {

    }
}
