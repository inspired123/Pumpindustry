<?php

namespace cms\core\menu\Models;

use Illuminate\Database\Eloquent\Model;

class AdminMenuPermissionModel extends Model
{
    protected $table = 'admin_menu_permission';
}
