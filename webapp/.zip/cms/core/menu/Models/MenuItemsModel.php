<?php

namespace cms\core\menu\Models;

use Illuminate\Database\Eloquent\Model;

class MenuItemsModel extends Model
{
    protected $table='menuitems';

}
