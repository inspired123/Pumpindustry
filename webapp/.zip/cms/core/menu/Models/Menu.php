<?php
namespace cms\core\menu\Models;
use Illuminate\Database\Eloquent\Model;
class Menu extends Model {

}