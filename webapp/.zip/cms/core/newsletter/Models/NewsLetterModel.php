<?php

namespace cms\core\newsletter\Models;

use Illuminate\Database\Eloquent\Model;

class NewsLetterModel extends Model
{
    protected $table = 'newsletter_subscribers';
}
