<?php

namespace cms\core\plugins\Models;

use Illuminate\Database\Eloquent\Model;

class PluginsModel extends Model
{
    protected $table = 'plugins';
}
