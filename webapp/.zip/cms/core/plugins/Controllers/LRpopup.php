<?php
namespace cms\core\plugins\Controllers;
class LRpopup
{
    function display()
    {
        return 'abc';
    }
}