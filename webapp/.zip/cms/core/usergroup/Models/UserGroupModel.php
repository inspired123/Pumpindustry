<?php

namespace cms\core\usergroup\Models;

use Illuminate\Database\Eloquent\Model;

class UserGroupModel extends Model
{
    protected $table='user_groups';
}
