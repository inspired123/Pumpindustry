<?php

namespace cms\core\usergroup\Models;

use Illuminate\Database\Eloquent\Model;

class UserGroupMapModel extends Model
{
    public $timestamps = false;
    protected $table='user_group_map';
}
