<?php

namespace cms\core\gate\Models;

use Illuminate\Database\Eloquent\Model;

class HasPermissionModel extends Model
{
    protected $table = 'has_permission';
}
