<?php
Route::get('search','SearchController@index');