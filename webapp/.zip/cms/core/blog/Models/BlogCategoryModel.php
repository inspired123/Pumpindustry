<?php

namespace cms\core\blog\Models;

use Illuminate\Database\Eloquent\Model;

class BlogCategoryModel extends Model
{
    protected $table = 'blog_category';
}
